.include "m328pdef.inc" ; Define device ATmega328P
.include "SetStack.inc"

.org 0x0000

setStack 0x08FF,R16

.include "delay_ms.inc"   ; inclui a macro para definição do delay

delayms 500   ; aciona um delay de 500ms
rjmp LOOP

.include "delay10ms.asm"


LOOP:
rjmp LOOP
